import 'package:flutter/material.dart';

class InfoPanel extends StatelessWidget {
  final ScrollController scrollController;
  final ValueNotifier<String> connectionStatus;
  final ValueNotifier<Map<String, dynamic>> telemetry;

  const InfoPanel({
    super.key,
    required this.scrollController,
    required this.connectionStatus,
    required this.telemetry,
  });

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<Map<String, dynamic>>(
      valueListenable: telemetry,
      builder: (context, jsonData, _) {
        if (jsonData.isEmpty) {
          return Center(
            child: ListView(
              controller: scrollController,
              padding: const EdgeInsets.all(16),
              children: const [
                SizedBox(height: 8),
                _Grabber(),
                SizedBox(height: 12),
                Center(
                  child: Text(
                    "No data received yet",
                    style: TextStyle(color: Colors.white70),
                  ),
                ),
              ],
            ),
          );
        }

        // 👇 NEW: motion_state pulled from your BLE JSON
        final motionState = (jsonData["motion_state"] ?? "Unknown").toString();
        final motionColor = _motionColor(motionState);

        return ListView(
          controller: scrollController,
          padding: const EdgeInsets.all(16),
          children: [
            const SizedBox(height: 8),
            const _Grabber(),
            const SizedBox(height: 12),

            const Center(
              child: Text(
                "Ride Telemetry",
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w600,
                  color: Colors.white,
                ),
              ),
            ),
            const SizedBox(height: 12),

            // 👇 NEW: Motion state tile (only addition)
            Container(
              padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 16),
              decoration: BoxDecoration(
                color: motionColor.withOpacity(0.15),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: motionColor.withOpacity(0.4)),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.directions_run, color: Colors.white, size: 22),
                  const SizedBox(width: 8),
                  Text(
                    "Motion: $motionState",
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: motionColor,
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 16),

            // Connection Status (unchanged)
            ValueListenableBuilder<String>(
              valueListenable: connectionStatus,
              builder: (context, status, _) => Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.bluetooth,
                    color: status.contains("Connected")
                        ? Colors.greenAccent
                        : Colors.orangeAccent,
                    size: 18,
                  ),
                  const SizedBox(width: 6),
                  Text(
                    status,
                    style: const TextStyle(color: Colors.white70, fontSize: 14),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 16),
            const Divider(color: Colors.white24),

            // Sensor Data Grid (unchanged)
            GridView.count(
              crossAxisCount: 2,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              childAspectRatio: 3.4,
              children: [
                _tile("Lat", jsonData["lat"]),
                _tile("Lng", jsonData["lng"]),
                _tile("Speed", jsonData["spd"] != null ? "${jsonData["spd"]} km/h" : "—"),
                _tile("Satellites", jsonData["sat"]),
                _tile("AX", jsonData["ax"]),
                _tile("AY", jsonData["ay"]),
                _tile("AZ", jsonData["az"]),
                _tile("Temp", jsonData["temp"] != null ? "${jsonData["temp"]}°C" : "—"),
              ],
            ),
            const Divider(color: Colors.white24),

            if (jsonData.containsKey("timestamp"))
              Center(
                child: Text(
                  "📅 ${jsonData["timestamp"]}",
                  style: const TextStyle(color: Colors.white54, fontSize: 13),
                ),
              ),
          ],
        );
      },
    );
  }

  static Widget _tile(String label, dynamic value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4, horizontal: 6),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.grey[900],
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: Colors.grey[800]!),
        ),
        padding: const EdgeInsets.all(10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(label,
                style: const TextStyle(
                    color: Colors.white70, fontSize: 12, fontWeight: FontWeight.w400)),
            const SizedBox(height: 4),
            Text(
              value?.toString() ?? "—",
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.w600,
                fontSize: 15,
              ),
            ),
          ],
        ),
      ),
    );
  }

  static Color _motionColor(String motion) {
    switch (motion.toLowerCase()) {
      case "walking":
        return Colors.greenAccent;
      case "running":
        return Colors.orangeAccent;
      case "stationary":
        return Colors.blueAccent;
      default:
        return Colors.white;
    }
  }
}

class _Grabber extends StatelessWidget {
  const _Grabber();

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        width: 50,
        height: 5,
        decoration: BoxDecoration(
          color: Colors.grey[700],
          borderRadius: BorderRadius.circular(10),
        ),
      ),
    );
  }
}
